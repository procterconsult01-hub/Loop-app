# Loop — real-time chat, media & calls

A working messaging app: accounts, real-time text chat (1:1 and groups), media
sharing (images/video/audio/files), and voice/video calls over WebRTC.

## What's real here
- **Accounts & auth** — phone + password, bcrypt-hashed, JWT sessions
- **Real-time messaging** — Socket.io, persisted to a JSON database, delivered live
- **Groups** — create a group, add members, group chat works like a DM
- **Media sharing** — upload images/video/audio/files, they render inline
- **Voice/video calls** — actual WebRTC peer-to-peer calls (1:1 only in this build), the server just relays the connection setup (signaling); audio/video itself flows directly between the two browsers

## What this is *not* (yet)
- **No end-to-end encryption.** Messages are stored in plaintext in the database and sent over your server's connection. Real E2E encryption (Signal Protocol, which is what WhatsApp uses) is a serious, separate project.
- **No TURN server.** Calls use only a public STUN server (Google's), which handles most home networks but not every network (symmetric NATs, strict corporate firewalls). Add a TURN server (self-hosted `coturn`, or a service like Twilio) before relying on this for calls across arbitrary networks.
- **No native mobile app.** This is a web app. It works on mobile browsers, but it's not an App Store/Play Store app.
- **Simple contact model.** Every registered user can see and message every other user — there's no phone-contact import or friend-request flow.

## Database

This uses **Postgres** now (via the `pg` package) instead of a JSON file, so data survives redeploys. Tables are created automatically on first run — no separate migration step needed.

## Running it locally

You need a Postgres instance. Easiest options: install Postgres locally, or run one in Docker:
```bash
docker run --name loop-postgres -e POSTGRES_PASSWORD=password -e POSTGRES_DB=loop -p 5432:5432 -d postgres
```

Then:
```bash
cd server
npm install
cp .env.example .env    # edit JWT_SECRET, and DATABASE_URL if not using the Docker command above
npm start
```

Then open `http://localhost:3001` in two different browser windows (or one normal + one incognito) and register two accounts to test messaging and calling between them.

Calls need camera/microphone permission — your browser will prompt for it.

## Deploying it for real

This is a single Node.js process serving both the API and the frontend, so it deploys easily to any Node host:

1. **Push this folder to a GitHub repo.**
2. **On [Railway](https://railway.app):**
   - New Project → Deploy from GitHub repo → pick your repo
   - In the service settings: **Root Directory** = `server`, **Build Command** = `npm install`, **Start Command** = `npm start`
   - Add a Postgres database: **New → Database → Add PostgreSQL** in the same project. Railway automatically injects `DATABASE_URL` into your service — no manual config needed.
   - Add an environment variable `JWT_SECRET` (a long random string — generate one with `openssl rand -base64 32`)
   - **Settings → Networking → Generate Domain** to get a free HTTPS URL — **HTTPS is required** for camera/mic access to work in the browser.
3. **Uploaded files still live on local disk** (`server/uploads/`), which is *not* redeploy-safe even with Postgres handling your data. For a real launch, move uploads to S3 or Cloudflare R2 — messages and accounts will already survive redeploys once Postgres is attached, but attached files won't until that piece is added too.

## Project structure

```
loop-app/
  server/
    server.js       # Express API + Socket.io (messaging + call signaling)
    db.js            # lowdb JSON database
    package.json
    .env.example
    uploads/          # uploaded media lands here
    data/             # db.json lives here
  public/
    index.html        # single-page app shell
    style.css
    app.js             # all client logic: auth, chat, WebRTC calls
```

## Sensible next steps, roughly in priority order

1. Move uploads to S3/R2 instead of local disk (the last redeploy-safety gap)
2. Add a TURN server for reliable calling across all networks
3. Add group video calls (needs an SFU like mediasoup/LiveKit — 1:1 P2P doesn't scale to groups)
4. Add read receipts, message editing/deletion, push notifications
5. If E2E encryption matters for your use case, look at the Signal Protocol (`libsignal`) — it's the real hard part of "build WhatsApp"
